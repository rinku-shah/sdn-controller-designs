onos 4 chains are working good with this controller code 
